package wiproTnp;

import java.util.*;

public class MileStone1 {

    public static void main(String[] args) {
        char[] arr1 = {'A', 'B', 'C'};
        char[] arr2 = {'B', 'C', 'D'};

        // Sets to store characters from both arrays and their intersection
        Set<Character> set1 = new HashSet<>();
        Set<Character> set2 = new HashSet<>();
        Set<Character> intersection = new HashSet<>();

        // Adding elements from the first array
        for (char c : arr1) {
            set1.add(c);
        }

        // Adding elements from the second array
        for (char c : arr2) {
            if (set1.contains(c)) {
                intersection.add(c);
            } else {
                set2.add(c);
            }
        }

        // Remove intersection elements from set1
        set1.removeAll(intersection);

        // Combine the unique elements from both sets
        set1.addAll(set2);

        // Convert the set back to a list (optional)
        List<Character> list = new ArrayList<>(set1);

        // Calculating the sum of ASCII values
        int sum = 0;
        for (char c : list) {
            sum += c;
        }

        // Calculating the sum of digits in the sum
        int digitSum = 0;
        int n = sum;
        while (n > 0) {
            int digit = n % 10;
            digitSum += digit;
            n /= 10;
        }

        // Printing the results
        System.out.println(list);
        System.out.println(sum);
        System.out.println(digitSum);
    }
}
