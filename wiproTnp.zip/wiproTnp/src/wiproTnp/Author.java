package wiproTnp;

public class Author {
		String name;
		String email;
		char gender;
		Author(String name,String email,char gender){
			this.name=name;
			this.email=email;
			this.gender=gender;
		}
		public String getName() {
			return name;
		}
		public String getEmail() {
			return email;
		}
		public char getGender() {
			return gender;
		}
		public void setName() {
			this.name=name;
		}
		public void setEmail() {
			this.email=email;
		}
		public String toString() {
	        return "Author[name=" + name + ", email=" + email + ", gender=" + gender + "]";
	    }
}
