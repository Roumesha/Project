package wiproTnp;



import java.util.Scanner;

class Video {

  private String videoName;
  private boolean checkout;
  private int rating;

  public Video(String name) {
    this.videoName = name;
    this.checkout = false;
    this.rating = 0;
  }

  public String getName() {
    return videoName;
  }

  public void doCheckout() {
    checkout = true;
  }

  public void doReturn() {
    checkout = false;
  }

  public void receiveRating(int rating) {
    this.rating = rating;
  }

  public int getRating() {
    return rating;
  }

  public boolean getCheckout() {
    return checkout;
  }
}

class VideoStore {

  private Video[] store;
  private int numVideos;

  public VideoStore() {
    store = new Video[100];
    numVideos = 0;
  }

  public void addVideo(String name) {
    store[numVideos] = new Video(name);
    numVideos++;
  }

  public void doCheckout(String name) {
    for (int i = 0; i < numVideos; i++) {
      if (store[i].getName().equals(name)) {
    	  switch (store[i].getCheckout() ? 1 : 0) {
    	  case 1: 
    	    System.out.println(name + " is already checked out.");
    	    return;
    	  case 0: 
    	    store[i].doCheckout();
    	    System.out.println(name + " checked out successfully!");
    	    return;
    	  default:
    	    break;
    	}

        }
      }
    System.out.println(name + " is not available in the store.");
  }

  public void doReturn(String name) {
    for (int i = 0; i < numVideos; i++) {
      if (store[i].getName().equals(name) && store[i].getCheckout()) {
        store[i].doReturn();
        System.out.println(name + " returned successfully!");
        return;
      }
    }
    System.out.println(name + " is not checked out or not in the store.");
  }

  public void receiveRating(String name, int rating) {
    for (int i = 0; i < numVideos; i++) {
      if (store[i].getName().equals(name) && !store[i].getCheckout()) {
        store[i].receiveRating(rating);
        System.out.println(name + " rating received: " + rating);
        return;
      }
    }
    System.out.println(name + " cannot be rated. It's either checked out or not in the store.");
  }

  public void listInventory() {
    System.out.println("Video Inventory:");
    for (int i = 0; i < numVideos; i++) {
      System.out.println(store[i].getName() + " (Available: " + !store[i].getCheckout() + ")");
    }
  }
}

public class VideoLauncher {
  public static void main(String[] args) {
    VideoStore store = new VideoStore();
    Scanner scanner = new Scanner(System.in); 
    String userChoice;
    do {
      System.out.println("menu:");
      System.out.println("1.Add Video");
      System.out.println("2.Check Out Video");
      System.out.println("3.Return Video");
      System.out.println("4.Rate Video");
      System.out.println("5.List Inventory");
      System.out.println("6.Exit");
      System.out.print("Enter your choice:");

      userChoice = scanner.nextLine();

      switch (userChoice) {
        case "1":
          System.out.print("Enter video name:");
          String newVideoName = scanner.nextLine();
          store.addVideo(newVideoName);
          System.out.println(newVideoName + " added to the store.");
          break;
       case "2":
          System.out.print("Enter video name to check out: ");
          String checkoutName = scanner.nextLine();
          store.doCheckout(checkoutName);
          break;
        case "3":
          System.out.print("Enter video name to return: ");
          String returnName = scanner.nextLine();
          store.doReturn(returnName);
          break;
        case "4":
          System.out.print("Enter video name to rate: ");
          String rateName = scanner.nextLine();
          System.out.print("Enter rating: ");
          int rating = scanner.nextInt();
          store.receiveRating(rateName, rating);
          scanner.nextLine(); 
          break;
        case "5":
          store.listInventory();
          break;
        case "6":
          System.out.println("Exiting the video store.");
          break;
        default:
          System.out.println("Invalid choice. Please enter a number between 1 and 6.");
      }
    } while (!userChoice.equals("6"));

   
    }
    }


