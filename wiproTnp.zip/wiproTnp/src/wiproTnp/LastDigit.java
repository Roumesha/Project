package wiproTnp;

import java.util.Scanner;

public class LastDigit {
	static void lastDigit(int n,int m){
		int a=n%10;
		int b=m%10;
		if(a==b) {
			System.out.println("true");
		}
		else {
			System.out.println("false");
		}
	}
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the two numbers");
		int n=sc.nextInt();
		int m=sc.nextInt();
		lastDigit(n,m);
	}
}
