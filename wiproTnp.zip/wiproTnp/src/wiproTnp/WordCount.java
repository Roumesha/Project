package wiproTnp;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
public class WordCount {
	
	
	    public static void main(String[] args) throws IOException {
	        Scanner sc = new Scanner(System.in);
	        System.out.println("Enter the file path:");
	        String filePath = sc.next();
	        FileWriter writer = new FileWriter(filePath);
	        System.out.println("Enter content to add to the file:");
	        String str = sc.next(); 
	        writer.write(str);
	        writer.close();
	        FileReader reader = new FileReader(filePath); 
	        BufferedReader br = new BufferedReader(reader);
	        System.out.println("Enter the output path:");
	        String outputPath = sc.next();
	        FileWriter writer2 = new FileWriter(outputPath);
	        Map<String, Integer> wordCounts = new HashMap<>();
	        String line;
	        while ((line = br.readLine()) != null) {
	            String[] words = line.split("\\s+"); 
	            for (String word : words) {
	                if (!word.isEmpty()) { 
	                    if (wordCounts.containsKey(word)) {
	                        wordCounts.put(word, wordCounts.get(word) + 1); 
	                    } else {
	                        wordCounts.put(word, 1); 
	                    }
	                }
	            }
	        }
	        for (Map.Entry<String, Integer> entry : wordCounts.entrySet()) {
	            String word = entry.getKey();
	            int count = entry.getValue();
	            String outputLine = String.format("%-20s %d\n", word, count); 
	            
	            System.out.println("Word: " + word + ", Count: " + count);  
	            writer2.write(outputLine); 
	        }

	        br.close();
	        reader.close();
	        writer2.close();
	        sc.close();
	    }
	}


