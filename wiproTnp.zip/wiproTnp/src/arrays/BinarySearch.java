package arrays;

import java.util.Scanner;

public class BinarySearch {
	static int Search(int search,int[] arr,int n) {
		for(int i=0;i<n;i++) {
			if(arr[i]==search) {
				return i;
			}	
		}
		return -1;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size of array");
		int n=sc.nextInt();
		int[] arr=new int[n];
		System.out.println("Enter elements");
		for(int i=0;i<n;i++) {
			arr[i]=sc.nextInt();
		}
		System.out.println("Enter search element");
		int search=sc.nextInt();
		System.out.println(Search(search,arr,n));
		
	}

}
