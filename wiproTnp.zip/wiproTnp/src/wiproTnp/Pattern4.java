package wiproTnp;

public class Pattern4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 *          1
		 *         12A
		 *        123BA
		 *       1234CBA
		 *      12345DCBA
		 *     123456EDCBA
		 *    1234567FEDCBA
		 *   12345678GFEDCBA
		 *  123456789HGFEDCBA
		 * 12345678910IHGFEDCBA
		 */
		for(int row=1;row<=10;row++) {
			for(int space=1;space<=10-row;space++) {
				System.out.print(" ");
			}
			for(int num=1;num<=row;num++) {
				System.out.print(num);
			}
			for(int num1=row-1;num1>0;num1--) {
				System.out.print((char)(num1+16+'0'));
				//System.out.print(num1);
			}
			System.out.println(" ");
		}
	}

}
