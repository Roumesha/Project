package wiproTnp;

public class Pattern3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 *          1
		 *         121
		 *        12321
		 *       1234321
		 *      123454321
		 *     12345654321
		 *    1234567654321
		 *   123456787654321
		 *  12345678987654321
		 * 12345678910987654321
		 */
		for(int row=1;row<=10;row++) {
			for(int space=1;space<=10-row;space++) {
				System.out.print(" ");
			}
			for(int num=1;num<=row;num++) {
				System.out.print(num);
			}
			for(int num1=row-1;num1>0;num1--) {
				System.out.print(num1);
			}
			System.out.println(" ");
		}

	}

}
