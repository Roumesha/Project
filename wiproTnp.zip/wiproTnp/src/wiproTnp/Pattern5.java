package wiproTnp;

public class Pattern5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 *          1
		 *         121
		 *        12321
		 *       1234321
		 *      123454321
		 *     12345654321
		 *    1234567654321
		 *   123456787654321
		 *  12345678987654321
		 * 12345678910987654321
		 *  12345678987654321
		 *   123456787654321
		 *    1234567654321
		 *     12345654321
		 *      123454321
		 *       1234321
		 *        12321
		 *         121
		 *          1
		 */
		for(int row=1;row<=10;row++) {
			for(int space=1;space<=10-row;space++) {
				System.out.print(" ");
			}
			for(int num=1;num<=row;num++) {
				System.out.print(num);
			}
			for(int num2=row-1;num2>0;num2--) {
				System.out.print(num2);
			}
			System.out.println(" ");
		}
		for(int row=9;row>0;row--) {
			for(int space=1;space<=10-row;space++) {
				System.out.print(" ");
			}
			for(int num=1;num<=row;num++) {
				System.out.print(num);
			}
			for(int num2=row-1;num2>0;num2--) {
				System.out.print(num2);
			}
			System.out.println(" ");
		}
	}

}
