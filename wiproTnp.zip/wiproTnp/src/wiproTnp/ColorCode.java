package wiproTnp;

import java.util.Scanner;

public class ColorCode {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a color code: ");
        String colorCode = scanner.next();
        String colorName;
        switch (colorCode) {
            case "R":
                colorName = "Red";
                break;
            case "G":
                colorName = "Green";
                break;
            case "B":
                colorName = "Blue";
                break;
            case "Y":
                colorName = "Yellow";
                break;
            case "O":
                colorName = "Orange";
                break;
            case "W":
                colorName = "White";
                break;
            default:
                colorName = "Invalid color code";
                break;
        }
        System.out.println("The color name is: " + colorName);
    }
}
