package wiproTnp;

public class Pattern1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * 1
		 * 12
		 * 123
		 * 1234
		 * 12345
		 * 123456
		 * 1234567
		 */
		for(int i=1;i<=10;i++) {
			for(int num=1;num<=i;num++) {
			System.out.print(num);
		}
			System.out.println(" ");
		}
		
	}

}
