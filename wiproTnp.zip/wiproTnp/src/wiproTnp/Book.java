package wiproTnp;


public class Book{
	String name;
    Author author;
    double price;
    int qtyInStock;
    public Book(String name, Author author, double price, int qtyInStock) {
        this.name = name;
        this.author = author;
        this.price = price;
        this.qtyInStock = qtyInStock;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Author getAuthor() {
        return author;
    }

    public void setAuthor(Author author) {
        this.author = author;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQtyInStock() {
        return qtyInStock;
    }

    public void setQtyInStock(int qtyInStock) {
        this.qtyInStock = qtyInStock;
    }

    
    public String toString() {
        return "Book[name=" + name + ", author=" + author + ", price=" + price + ", qtyInStock=" + qtyInStock + "]";
    }
    public static void main(String args[]) {
    	Author author = new Author("J.K. Rowling", "jk.rowling@gmail.com", 'F');
        Book book = new Book("Harry Potter", author, 29.99, 1000);

        System.out.println(book);
    }
}

