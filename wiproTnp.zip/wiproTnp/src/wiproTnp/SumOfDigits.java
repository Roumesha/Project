package wiproTnp;

import java.util.Scanner;

public class SumOfDigits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number");
		int n =sc.nextInt();
		int sum=0;
		int num=n;
		int digit;
		while(num>0) {
			digit=num%10;
			sum+=digit;
			num=num/10;
		}
		System.out.println(sum);
	}

}
